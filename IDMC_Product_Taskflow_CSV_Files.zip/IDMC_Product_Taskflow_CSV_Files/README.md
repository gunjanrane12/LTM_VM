IDMC Product Taskflow CSV Demo Files

Business case:
A retail store maintains product master data, prices, inventory, and product review status.

Suggested demonstrations:
1. Sequential taskflow:
   PRODUCTS.csv -> load PRODUCT master -> load PRODUCT prices -> load inventory.
   Use PRODUCT_PRICES.csv and PRODUCT_INVENTORY.csv as separate sources if you want distinct mapping tasks.

2. Parallel taskflow:
   In parallel, load PRODUCTS.csv, PRODUCT_PRICES.csv, and PRODUCT_INVENTORY.csv into their matching target tables.

3. Parallel taskflow with control/decision logic:
   PRODUCT_LOAD_CONTROL.csv demonstrates dataset-level load flags (Y/N). In IDMC, make the flag available to the taskflow as an input/output or lookup result; a Decision step does not automatically query or filter CSV rows.

4. Sequential taskflow with decision:
   PRODUCT_REVIEW_CONTROL.csv contains PRICE_REVIEW_REQUIRED. For a taskflow Decision, pass a single product's flag as a taskflow input/output value, or use separate filtered mappings for row-level routing.
   Expected row-level outcomes are provided in PRODUCT_PRICE_REVIEW_TARGET_EXPECTED.csv and PRODUCT_STANDARD_TARGET_EXPECTED.csv.

5. Product status routing:
   PRODUCT_ACTIVE_TARGET_EXPECTED.csv and PRODUCT_OUT_OF_STOCK_TARGET_EXPECTED.csv show expected outputs when mapping logic filters ACTIVE versus OUT_OF_STOCK products.

These CSVs are sample data for demonstration; expected target CSVs are reference outputs, not source files that must all be loaded.



# IDMC Product Taskflow Demo — Detailed Implementation Guide

## 1. Purpose

This package supports a small retail product-management demonstration in Informatica Intelligent Data Management Cloud (IDMC). It covers four orchestration patterns:

1. Sequential Taskflow
2. Parallel Taskflow
3. Sequential Taskflow with a Decision
4. Parallel Taskflow with Decisions / conditional branches

The business case is a store that maintains product master data, prices, inventory, and product-review information.

> Important distinction: a Taskflow Decision evaluates taskflow-level conditions and available input/output values. It does not automatically evaluate every row in a CSV source. For decisions on individual product rows, implement row filtering/routing in a mapping, or process one product per taskflow invocation with its status passed as a taskflow input. The examples below identify where each approach applies.

---

## 2. Files in this package

### Source CSVs

| File | Purpose | Key columns |
|---|---|---|
| `PRODUCTS.csv` | Main product master | PRODUCT_ID, PRODUCT_NAME, CATEGORY, UNIT_PRICE, STOCK_QTY, PRODUCT_STATUS |
| `PRODUCT_PRICES.csv` | Price data for the pricing load | PRODUCT_ID, PRODUCT_NAME, UNIT_PRICE |
| `PRODUCT_INVENTORY.csv` | Inventory data for the stock load | PRODUCT_ID, PRODUCT_NAME, STOCK_QTY |
| `PRODUCT_CATEGORIES.csv` | Category reference data | CATEGORY_ID, CATEGORY, CATEGORY_MANAGER |
| `PRODUCT_LOAD_CONTROL.csv` | Dataset-level load configuration | DATASET_NAME, LOAD_FLAG |
| `PRODUCT_REVIEW_CONTROL.csv` | Product-level review flags for the conditional-routing example | PRODUCT_ID, PRODUCT_NAME, UNIT_PRICE, STOCK_QTY, PRODUCT_STATUS, PRICE_REVIEW_REQUIRED |

### Expected-output examples

| File | Purpose |
|---|---|
| `PRODUCT_ACTIVE_TARGET_EXPECTED.csv` | Expected rows when filtering active products |
| `PRODUCT_OUT_OF_STOCK_TARGET_EXPECTED.csv` | Expected rows when filtering out-of-stock products |
| `PRODUCT_PRICE_REVIEW_TARGET_EXPECTED.csv` | Expected rows where PRICE_REVIEW_REQUIRED = Y |
| `PRODUCT_STANDARD_TARGET_EXPECTED.csv` | Expected rows where PRICE_REVIEW_REQUIRED = N |

The expected-output CSVs are examples for validation. They are not required source inputs.

---

## 3. Before building the taskflows

1. Extract the ZIP file.
2. In IDMC, confirm that a Secure Agent is available and running if your organization uses one for local/file-based sources.
3. Create or confirm a flat-file connection that can read the extracted CSV files. Exact connection setup depends on your IDMC organization and Secure Agent configuration.
4. Import each source CSV as a source object or configure it as a delimited flat-file source in the mapping.
5. Create target objects. For a simple demo, use flat-file targets or database tables, depending on the environment.
6. Create and validate the mappings before adding them to a taskflow.
7. Give mappings and tasks clear names, for example:
   - `m_Load_Products`
   - `m_Load_Product_Prices`
   - `m_Load_Product_Inventory`
   - `m_Load_Product_Categories`
   - `m_Load_Price_Review`
   - `m_Load_Standard_Products`

CSV file paths and connection options vary by environment. Use the path and connection properties configured for your Secure Agent; do not assume that a file uploaded to your desktop is automatically available to the agent.

---

# CASE 1 — Sequential Taskflow (no Decision)

## Business requirement

Load the product master first, then load product prices, and finally load inventory. Each task must start only after the previous task succeeds.

## Flow

`Start -> Load Products -> Load Product Prices -> Load Product Inventory -> End`

## Implementation

### Step 1: Create and validate mappings

Create these mappings and corresponding Mapping Tasks:

| Mapping / task | Source | Target |
|---|---|---|
| `m_Load_Products` / `mt_Load_Products` | `PRODUCTS.csv` | `PRODUCTS_TARGET` |
| `m_Load_Product_Prices` / `mt_Load_Product_Prices` | `PRODUCT_PRICES.csv` | `PRODUCT_PRICES_TARGET` |
| `m_Load_Product_Inventory` / `mt_Load_Product_Inventory` | `PRODUCT_INVENTORY.csv` | `PRODUCT_INVENTORY_TARGET` |

Map source columns to matching target columns. If target columns have different names or types, configure the field mappings and data types accordingly.

### Step 2: Create the taskflow

1. Create a new taskflow, for example `tf_Sequential_Product_Load`.
2. Add the Start step.
3. Add the first Data Task / Mapping Task step and select `mt_Load_Products`.
4. Connect its successful completion path to the second task, `mt_Load_Product_Prices`.
5. Connect the second task to `mt_Load_Product_Inventory`.
6. Connect the final task to End.
7. Configure failure handling as appropriate for your demo. To demonstrate strict sequencing, do not connect a failure path to the next normal load task.
8. Save, validate, and run the taskflow.

### Step 3: Verify the order

| Sequence | Task | Expected check |
|---:|---|---|
| 1 | Load Products | Product master target is populated |
| 2 | Load Product Prices | Starts after the product load succeeds |
| 3 | Load Product Inventory | Starts after the price load succeeds |

**Demo explanation:** “This taskflow enforces a fixed order. Product loading completes before pricing starts, and pricing completes before inventory starts.”

**Important:** This ordering is an orchestration example. If the three datasets are genuinely independent, a parallel design may finish faster.

---

# CASE 2 — Parallel Taskflow (no Decision)

## Business requirement

Load product master, prices, and inventory at the same time because the three loads are independent.

## Flow

`Start -> Parallel Paths -> [Load Products | Load Prices | Load Inventory] -> End`

The three tasks are sibling branches under a Parallel Paths step. The taskflow proceeds beyond the parallel step after the parallel branches reach their completion condition according to the taskflow configuration.

## Implementation

### Step 1: Reuse the mappings

Use the same validated Mapping Tasks from Case 1:

- `mt_Load_Products`
- `mt_Load_Product_Prices`
- `mt_Load_Product_Inventory`

### Step 2: Create the taskflow

1. Create `tf_Parallel_Product_Load`.
2. Add Start.
3. Add a Parallel Paths step.
4. Create three branches from the parallel step.
5. Add `mt_Load_Products` to Branch 1.
6. Add `mt_Load_Product_Prices` to Branch 2.
7. Add `mt_Load_Product_Inventory` to Branch 3.
8. Connect the branches according to the taskflow designer's supported parallel-path structure and connect completion to End.
9. Configure and test branch failure behavior; do not assume that one branch's failure automatically cancels all other branches.
10. Save, validate, and run.

### Step 3: Verify

| Branch | Task | Target |
|---|---|---|
| 1 | Load Products | `PRODUCTS_TARGET` |
| 2 | Load Product Prices | `PRODUCT_PRICES_TARGET` |
| 3 | Load Product Inventory | `PRODUCT_INVENTORY_TARGET` |

**Demo explanation:** “The three independent loads start in parallel rather than waiting for one another. The overall taskflow completes when the configured parallel branches finish.”

**Expected result:** Each target should contain the corresponding rows from its source CSV. Completion order may vary from run to run.

--- 

# CASE 3 — Sequential Taskflow with a Decision

## Business requirement

Process one product at a time. After receiving a product's review flag, decide whether to send that product through the price-review process or the standard product process.

- `PRICE_REVIEW_REQUIRED = Y` -> run the price-review task.
- `PRICE_REVIEW_REQUIRED = N` -> run the standard product task.

## Data

Use `PRODUCT_REVIEW_CONTROL.csv`.

| PRODUCT_ID | PRODUCT_NAME | PRICE_REVIEW_REQUIRED |
|---:|---|---|
| 101 | Dell Laptop | Y |
| 102 | Samsung Mobile | N |
| 103 | Office Chair | Y |
| 104 | Wireless Mouse | N |

## Important design choice

A Taskflow Decision is not a row-by-row filter over this CSV. To demonstrate a real taskflow Decision, use one of these patterns:

**Option A — One product per taskflow run (clearest taskflow Decision demo):**
- Define taskflow input fields such as `in_PRODUCT_ID` and `in_PRICE_REVIEW_REQUIRED`.
- Start a taskflow run with one product's values.
- Evaluate `in_PRICE_REVIEW_REQUIRED` in a Decision step.
- Route to the corresponding task.
- Run once for each product, or invoke the taskflow from a supported parent/orchestration pattern.

**Option B — Process all products in one mapping (best for bulk row routing):**
- Use `PRODUCT_REVIEW_CONTROL.csv` as a source in a mapping.
- Use a Router transformation or Filter transformations to split rows by `PRICE_REVIEW_REQUIRED`.
- Load the `Y` group into the price-review target and the `N` group into the standard target.
- This is row-level mapping logic, not a taskflow Decision.

## Option A implementation: one product per taskflow run

### Step 1: Create the tasks

| Task | Purpose | Output |
|---|---|---|
| `mt_Load_Price_Review` | Processes the selected product when review flag is Y | `PRODUCT_PRICE_REVIEW_TARGET` |
| `mt_Load_Standard_Product` | Processes the selected product when review flag is N | `PRODUCT_STANDARD_TARGET` |

Configure the mappings so they process the intended product, for example by filtering on `PRODUCT_ID` supplied as a mapping parameter, where supported by the mapping/task configuration.

### Step 2: Create the taskflow

1. Create `tf_Sequential_Product_Decision`.
2. Define taskflow input fields `in_PRODUCT_ID` (integer) and `in_PRICE_REVIEW_REQUIRED` (string).
3. Add Start.
4. Add a Decision step after Start.
5. Configure a branch condition `in_PRICE_REVIEW_REQUIRED = 'Y'`.
6. On the Y path, run `mt_Load_Price_Review`.
7. Configure the alternative/default path for `in_PRICE_REVIEW_REQUIRED = 'N'` and run `mt_Load_Standard_Product`.
8. Connect the selected path to End.
9. Save, validate, and test with input values for both Y and N.

Use the exact syntax and branch configuration offered by your IDMC taskflow designer; condition expressions and input mapping labels can vary by taskflow version.

### Step 3: Test with examples

| Test run | PRODUCT_ID | Flag | Expected path |
|---:|---:|---|---|
| 1 | 101 | Y | Price review |
| 2 | 102 | N | Standard product |
| 3 | 103 | Y | Price review |
| 4 | 104 | N | Standard product |

Expected reference outputs for a bulk test are `PRODUCT_PRICE_REVIEW_TARGET_EXPECTED.csv` and `PRODUCT_STANDARD_TARGET_EXPECTED.csv`. With one-product-per-run, each run should load only the selected product.

**Demo explanation:** “The steps are sequential, but the Decision selects which task executes next based on the taskflow input.”

---

# CASE 4 — Parallel Taskflow with Decisions / conditional branches

## Business requirement

Run two independent dataset-loading processes in parallel, but use a load-control value to decide whether each dataset's load task should execute.

Use `PRODUCT_LOAD_CONTROL.csv`:

| DATASET_NAME | LOAD_FLAG |
|---|---|
| PRODUCTS | Y |
| PRODUCT_PRICES | Y |
| PRODUCT_INVENTORY | N |

Expected behavior:
- Products: load.
- Prices: load.
- Inventory: skip.

## Critical implementation note

The `PRODUCT_LOAD_CONTROL.csv` file does not automatically drive a Taskflow Decision. The control value must be made available to the taskflow as an input, output, or other supported value from a prior step. A taskflow Decision generally evaluates a taskflow-level condition; it does not loop through control-table rows by itself.

For a clear demo, use dataset-level flags passed into the taskflow. If you need the taskflow to dynamically read an arbitrary number of control-table rows and launch a variable set of branches, that requires a more advanced orchestration design and depends on the capabilities available in your IDMC edition and taskflow features.

## Recommended implementation: three independent conditional branches

### Step 1: Create/validate the load tasks

| Dataset | Mapping Task | Target |
|---|---|---|
| Products | `mt_Load_Products` | `PRODUCTS_TARGET` |
| Prices | `mt_Load_Product_Prices` | `PRODUCT_PRICES_TARGET` |
| Inventory | `mt_Load_Product_Inventory` | `PRODUCT_INVENTORY_TARGET` |

### Step 2: Provide load flags

For a fixed demo, define taskflow inputs:

- `in_LOAD_PRODUCTS` (string, Y/N)
- `in_LOAD_PRICES` (string, Y/N)
- `in_LOAD_INVENTORY` (string, Y/N)

Set the demo inputs to:
- `in_LOAD_PRODUCTS = Y`
- `in_LOAD_PRICES = Y`
- `in_LOAD_INVENTORY = N`

These values mirror `PRODUCT_LOAD_CONTROL.csv`. If you want the taskflow to read the CSV itself, add a supported pre-processing step to read/interpret that configuration and pass values into the taskflow; do not assume the Decision step can read the CSV directly.

### Step 3: Build the taskflow

1. Create `tf_Parallel_Product_Decisions`.
2. Add Start.
3. Add a Parallel Paths step with three branches.
4. In Branch 1, add a Decision that evaluates `in_LOAD_PRODUCTS = 'Y'`. On the Y path, run `mt_Load_Products`; on the N/default path, skip the load and complete that branch.
5. In Branch 2, evaluate `in_LOAD_PRICES = 'Y'`. On Y, run `mt_Load_Product_Prices`; otherwise skip it.
6. In Branch 3, evaluate `in_LOAD_INVENTORY = 'Y'`. On Y, run `mt_Load_Product_Inventory`; otherwise skip it.
7. Connect each branch so both the load path and skip path reach that branch's completion point, using the structure supported by the taskflow designer.
8. Connect the parallel branches to the taskflow's completion/End path.
9. Save, validate, and run with the sample flags.

If your IDMC taskflow designer/version does not support a Decision step nested in the desired parallel structure, implement each conditional load as a child taskflow or use another supported orchestration pattern. Verify the exact supported nesting and branch-join rules in your tenant.

### Step 4: Expected result

| Dataset | Flag | Action | Expected outcome |
|---|---|---|---|
| Products | Y | Execute load | Products target populated |
| Prices | Y | Execute load | Prices target populated |
| Inventory | N | Skip load | Inventory target not loaded by this run |

**Demo explanation:** “The branches are independent and run in parallel. Each branch checks its own load flag, so a dataset can be loaded or skipped without making the other branches wait for its data load.”

---

## 4. Quick comparison of all four cases

| Case | Orchestration | Conditional? | Business example |
|---|---|---|---|
| 1. Sequential | Fixed, one after another | No | Product -> Prices -> Inventory |
| 2. Parallel | Independent tasks concurrently | No | Products, prices, inventory together |
| 3. Sequential + Decision | Ordered flow with a selected path | Yes | Review a product or process it normally |
| 4. Parallel + Decisions | Independent branches with conditional execution | Yes | Load or skip each dataset independently |

---

## 5. Validation checklist for the demo

- [ ] Each CSV source can be read successfully by IDMC.
- [ ] Every mapping is valid and its source-to-target field mapping is correct.
- [ ] Sequential case: run history shows the intended task order.
- [ ] Parallel case: run history shows three branches launched from the parallel step; completion order may differ.
- [ ] Sequential Decision case: test one Y input and one N input and confirm different paths.
- [ ] Parallel Decision case: test Y/Y/N and confirm the third load is skipped while the other two run.
- [ ] Inspect target rows and row counts.
- [ ] Review taskflow and mapping logs for failures.
- [ ] Test failure handling deliberately if time allows, and explain whether the flow stops, continues, or follows a configured error path.

## 6. Suggested live demonstration script

1. Show `PRODUCTS.csv`, `PRODUCT_PRICES.csv`, and `PRODUCT_INVENTORY.csv`.
2. Run the sequential flow and show the fixed execution order.
3. Run the parallel flow and show that all three branches can execute concurrently.
4. Run the sequential Decision flow with `PRICE_REVIEW_REQUIRED = Y`, then with `N`.
5. Run the parallel Decision flow with load flags Y/Y/N and show that Products and Prices load while Inventory is skipped.
6. Finish by summarizing: sequential controls order, parallel enables concurrency, and Decisions choose paths based on conditions.

## 7. Practical cautions

- A taskflow Decision is not the same as a mapping Filter or Router.
- A CSV control table does not automatically become a taskflow variable. You must explicitly read or pass its values through supported taskflow inputs/outputs or another configured step.
- Do not expect a taskflow Decision to split every row in a dataset. Use mapping-level row routing for that.
- Confirm taskflow step names, nesting support, parameter syntax, and parallel-path join behavior in your IDMC tenant/version.
- Expected-output files are examples to compare against. They are not automatically generated by running the taskflows.